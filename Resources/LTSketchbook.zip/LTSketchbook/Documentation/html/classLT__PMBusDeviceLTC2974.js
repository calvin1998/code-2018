var classLT__PMBusDeviceLTC2974 =
[
    [ "clearFaultLog", "classLT__PMBusDeviceLTC2974.html#aca9d4e80310e4d5d49141032b54a6bcd", null ],
    [ "detect", "classLT__PMBusDeviceLTC2974.html#a080f643e94591d8fab189e4247c42350", null ],
    [ "disableFaultLog", "classLT__PMBusDeviceLTC2974.html#ac2d93e881fab7ba52a668268cc6d4ac5", null ],
    [ "enableFaultLog", "classLT__PMBusDeviceLTC2974.html#ac8b0b50c82c5ea5255cb77b6f46334a6", null ],
    [ "getCapabilities", "classLT__PMBusDeviceLTC2974.html#ab5c8966573ed6c37d79a64d226424104", null ],
    [ "getFaultLog", "classLT__PMBusDeviceLTC2974.html#ac20784b2123e9268324f2f7abcb52638", null ],
    [ "getNumPages", "classLT__PMBusDeviceLTC2974.html#a417310f7a667ce0cb3b7c2519ee86eb2", null ],
    [ "getType", "classLT__PMBusDeviceLTC2974.html#af96e7dbd74a7ff1af9c2ce6e2eb0fe04", null ],
    [ "hasCapability", "classLT__PMBusDeviceLTC2974.html#ac396b420ab9be86dc20a492a7dad7136", null ],
    [ "hasFaultLog", "classLT__PMBusDeviceLTC2974.html#acccab9d232d5774f7faadda74c2917e6", null ],
    [ "LT_PMBusDeviceLTC2974", "classLT__PMBusDeviceLTC2974.html#a20e91fa24dc216d7a90c344ca81f5c05", null ],
    [ "cap_", "classLT__PMBusDeviceLTC2974.html#afb3fd22d5190235efe8b3f60515fbf22", null ]
];