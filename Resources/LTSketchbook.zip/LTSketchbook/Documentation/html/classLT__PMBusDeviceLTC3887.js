var classLT__PMBusDeviceLTC3887 =
[
    [ "detect", "classLT__PMBusDeviceLTC3887.html#af47795a69ea28749d4cc627f36354fa5", null ],
    [ "getCapabilities", "classLT__PMBusDeviceLTC3887.html#a80d9bf52b8193860258241775f3a20b3", null ],
    [ "getNumPages", "classLT__PMBusDeviceLTC3887.html#aa23e20e3cedfd314a893d2037cd3010b", null ],
    [ "hasCapability", "classLT__PMBusDeviceLTC3887.html#a8714e4d10e7bcaaf33bb8749b4493356", null ],
    [ "LT_PMBusDeviceLTC3887", "classLT__PMBusDeviceLTC3887.html#a3a12a061477de4a1eb1452b20150087d", null ],
    [ "cap_", "classLT__PMBusDeviceLTC3887.html#a03497ca41ac4b37218ed7aa508498c5a", null ]
];