var DC1795A_8ino =
[
    [ "field_menu_RW", "DC1795A_8ino.html#adf3309198c85040209dd22d61503d3a4", null ],
    [ "loop", "DC1795A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "LTC6950_Fout_Freq_Verification", "DC1795A_8ino.html#ad5ec27feb0e7f0e1619bc92035128e9d", null ],
    [ "LTC6950_Ref_Freq_Verification", "DC1795A_8ino.html#aa7037784435208543695dcd2cdce6607", null ],
    [ "LTC6950_VCO_Freq_Verification", "DC1795A_8ino.html#ab264e172c40c996fb7dccfd051a4945b", null ],
    [ "menu_1_load_default_settings", "DC1795A_8ino.html#a08d7e7cd8ce8442e1ff9b7d2401606ad", null ],
    [ "menu_2_RW_to_reg_addresss", "DC1795A_8ino.html#a31e0453493afb25fab235cbf6c029a13", null ],
    [ "menu_3_RW_to_reg_field", "DC1795A_8ino.html#af01e68716c433b62839fa83f5f178df2", null ],
    [ "menu_4_set_frf", "DC1795A_8ino.html#a7f6c7271c549953f95ddebd25d750f4f", null ],
    [ "menu_5_store_settings", "DC1795A_8ino.html#af2c96fe37e4b77af70cce56a6378a75a", null ],
    [ "menu_6_restore_settings", "DC1795A_8ino.html#a494fab0feebcf542f93ff85fa0e226d8", null ],
    [ "print_prompt", "DC1795A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1795A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "setup", "DC1795A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "demo_board_connected", "DC1795A_8ino.html#a6b6612d3ffc7cc8c4a57d8d0ba6d80d4", null ],
    [ "First_Run", "DC1795A_8ino.html#a55650e1ac6c9c9972e148d69d3571108", null ],
    [ "ref_out", "DC1795A_8ino.html#ab0ef22dd49c973c82d3ce8eb691a106a", null ]
];