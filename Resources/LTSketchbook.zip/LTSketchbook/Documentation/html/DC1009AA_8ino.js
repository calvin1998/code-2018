var DC1009AA_8ino =
[
    [ "loop", "DC1009AA_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_single_ended", "DC1009AA_8ino.html#a5095ec15d6797f7bf28227f165dea415", null ],
    [ "menu_2_read_differential", "DC1009AA_8ino.html#a4a5d0562e0e2306d5e55741c8c694840", null ],
    [ "menu_3_set_1X2X", "DC1009AA_8ino.html#a6e06811de91fb78253409104d65c966b", null ],
    [ "menu_4_select_rejection_freq", "DC1009AA_8ino.html#a31688f36701602724365bbb6d02d9fcf", null ],
    [ "print_prompt", "DC1009AA_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1009AA_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "DC1009AA_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "setup", "DC1009AA_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "BUILD_1X_2X_COMMAND", "DC1009AA_8ino.html#af746eaf3f5a3843975e41ed0fe18708b", null ],
    [ "BUILD_COMMAND_DIFF", "DC1009AA_8ino.html#a7a344b3881ac61627efb8e6cf87f99d6", null ],
    [ "BUILD_COMMAND_SINGLE_ENDED", "DC1009AA_8ino.html#a097d02287c914baf1ac6333b1769f961", null ],
    [ "BUILD_FREQ_REJ_COMMAND", "DC1009AA_8ino.html#a6091c1dccdb90f4cb611cb49c5766669", null ],
    [ "demo_board_connected", "DC1009AA_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ],
    [ "eoc_timeout", "DC1009AA_8ino.html#ac9e6544152d48e7780b787e2fb92c059", null ],
    [ "LTC2492_vref", "DC1009AA_8ino.html#af811cb800833a84a227dc3d6c78ba02e", null ],
    [ "rejection_mode", "DC1009AA_8ino.html#ac34538bf688df0a154db50a4af83111a", null ],
    [ "two_x_mode", "DC1009AA_8ino.html#a2b06467b3b344961c7a0141400d0591a", null ]
];