var DC1558__DC1808_8ino =
[
    [ "discover_demo_boards", "DC1558__DC1808_8ino.html#a5190e64ce9186866e62b3875a9af7498", null ],
    [ "loop", "DC1558__DC1808_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "LTC3589_print_all_registers", "DC1558__DC1808_8ino.html#a1272ce721a1d48a181e6ee8478666e37", null ],
    [ "menu_1_read_write_registers", "DC1558__DC1808_8ino.html#a72f314c33a46d0f2b6ed5941a0a8527e", null ],
    [ "menu_2_regulator_settings", "DC1558__DC1808_8ino.html#a711d476572072952ef67b6d2b35bb466", null ],
    [ "menu_3_sequencing", "DC1558__DC1808_8ino.html#ae4d438da64739801b04dd7a41b5fdde4", null ],
    [ "print_prompt", "DC1558__DC1808_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1558__DC1808_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_warning_prompt", "DC1558__DC1808_8ino.html#a7eba913bde59a1c1972f731a7586f393", null ],
    [ "setup", "DC1558__DC1808_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "valid_register", "DC1558__DC1808_8ino.html#a50d3fbe2abcc3ab5614c0cad66e01379", null ],
    [ "board_option", "DC1558__DC1808_8ino.html#a6d9075d6f1afbb76ee91796d4c4de6aa", null ],
    [ "delay_ms", "DC1558__DC1808_8ino.html#ae9e9bf17e37a05572bcc2a576565122e", null ],
    [ "demo_board_connected", "DC1558__DC1808_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ],
    [ "demo_name_1", "DC1558__DC1808_8ino.html#a9829ba78ac287b64fe07b8f3759e7cad", null ],
    [ "demo_name_2", "DC1558__DC1808_8ino.html#aa98d7a480f7b854a9f8277a98aca60c8", null ],
    [ "i2c_address", "DC1558__DC1808_8ino.html#afd5dbf719bae2b1ea9260a55e7c289cf", null ],
    [ "reg_phase", "DC1558__DC1808_8ino.html#ac0c3076252ded0343ac3a592782c6c29", null ],
    [ "reg_read_list", "DC1558__DC1808_8ino.html#a8751ef62969b6557d86affd14becdada", null ],
    [ "reg_write_list", "DC1558__DC1808_8ino.html#a3a17a5710de14833acb837a3c58a00e0", null ]
];