var DC1491A_8ino =
[
    [ "loop", "DC1491A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_30Hz_mode", "DC1491A_8ino.html#a0da901309f3a17ae6f80e2c4ffe6c85f", null ],
    [ "menu_2_sleep_mode", "DC1491A_8ino.html#acfd14dcf50d148454321771d9a1e02ac", null ],
    [ "menu_3_read_60Hz_mode", "DC1491A_8ino.html#a2092c15d01f0ad4f5ad33f21f81cd017", null ],
    [ "menu_4_calibrate", "DC1491A_8ino.html#ae99896933ad0a79b90db49dea44ad88b", null ],
    [ "print_prompt", "DC1491A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1491A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "restore_calibration", "DC1491A_8ino.html#a8a2c607e019908d9e92698fa842e0c28", null ],
    [ "setup", "DC1491A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "store_calibration", "DC1491A_8ino.html#a7c5befd5ab914622919e68a8af53edd2", null ],
    [ "demo_board_connected", "DC1491A_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ],
    [ "LTC2461_lsb", "DC1491A_8ino.html#a008aae67a97278566e6b23fbecb823f9", null ],
    [ "LTC2461_offset_code", "DC1491A_8ino.html#a5e1d3502309017e3817ef0bc24e3a553", null ]
];