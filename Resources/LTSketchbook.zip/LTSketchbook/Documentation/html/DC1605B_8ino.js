var DC1605B_8ino =
[
    [ "dc1605_write_dac_voltage", "DC1605B_8ino.html#afd188b6ef538eb3d38ea6c0552198d44", null ],
    [ "dc1605b_is_address_0x5n", "DC1605B_8ino.html#a08c3835f638513d95657de6a4da4c855", null ],
    [ "dc1605b_print_address_warning", "DC1605B_8ino.html#a36a9f549a62952e97d429e6d613baf9c", null ],
    [ "loop", "DC1605B_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "ltc2936_clear_alertb", "DC1605B_8ino.html#a51002c017040e83b3367ff8c82768165", null ],
    [ "ltc2936_demo_board_defaults", "DC1605B_8ino.html#a2d212f088cd82697b3741852803d0113", null ],
    [ "ltc2936_demo_board_demo_thresholds", "DC1605B_8ino.html#a6a8b98916a071f9aa5d2333046f7520f", null ],
    [ "ltc2936_is_write_protected", "DC1605B_8ino.html#af08ea748425ea0b9383388a336a0ff70", null ],
    [ "ltc2936_read_registers", "DC1605B_8ino.html#ab25f88af0b87c40bd2aca9b189ea39a1", null ],
    [ "print_prompt", "DC1605B_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1605B_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_warning_prompt", "DC1605B_8ino.html#a7eba913bde59a1c1972f731a7586f393", null ],
    [ "setup", "DC1605B_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "DC1605_DAC_ADDRESS", "DC1605B_8ino.html#a4c50ac1377a8b51179ae12b903005280", null ],
    [ "LTC2936_I2C_ADDRESS", "DC1605B_8ino.html#a75d475164a40089ed87852bbc3fb9106", null ],
    [ "dc1605_dac_address", "DC1605B_8ino.html#aa579b236eb00815aef0c547f39149126", null ],
    [ "ltc2936_i2c_address", "DC1605B_8ino.html#a451a571c0bba3adaa7229143aaa479a1", null ],
    [ "smbus", "DC1605B_8ino.html#a345ebedd28a646dfe8397c92eddc9b78", null ]
];