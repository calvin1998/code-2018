var DC1633B_8ino =
[
    [ "dc1633_write_dac_voltage", "DC1633B_8ino.html#aa9afe557840a9ad1afc7f7886b06ff04", null ],
    [ "loop", "DC1633B_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "ltc2933_clear_alertb", "DC1633B_8ino.html#a1a2810153b84656d3267efb323274c9e", null ],
    [ "ltc2933_demo_board_defaults", "DC1633B_8ino.html#a9c11ea9f1eb5fadb9e536e3e357e38c4", null ],
    [ "ltc2933_demo_board_demo_thresholds", "DC1633B_8ino.html#a11e5ca2640e497ae83cdb1c431ccf366", null ],
    [ "ltc2933_is_write_protected", "DC1633B_8ino.html#a6130e9e376c60751e525e2d4ddcc8d44", null ],
    [ "ltc2933_read_registers", "DC1633B_8ino.html#a6db348bab6964d8d93e05946969411f0", null ],
    [ "print_prompt", "DC1633B_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1633B_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_warning_prompt", "DC1633B_8ino.html#a7eba913bde59a1c1972f731a7586f393", null ],
    [ "setup", "DC1633B_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "DC1633_DAC_ADDRESS", "DC1633B_8ino.html#af6d95fda1f75f9daa3c26836bdb1e138", null ],
    [ "LTC2933_I2C_ADDRESS", "DC1633B_8ino.html#aa1b33a5120570f36f8f7da77081297b4", null ],
    [ "dc1633_dac_address", "DC1633B_8ino.html#adbb8e8629aa2d8dacec784582ea646a4", null ],
    [ "ltc2933_i2c_address", "DC1633B_8ino.html#af7929d70e62a832c2fb14ce9a5bcc43a", null ],
    [ "smbus", "DC1633B_8ino.html#a345ebedd28a646dfe8397c92eddc9b78", null ]
];