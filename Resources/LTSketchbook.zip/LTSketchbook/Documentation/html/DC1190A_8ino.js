var DC1190A_8ino =
[
    [ "loop", "DC1190A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_input", "DC1190A_8ino.html#a566d3e9aaa73069867f553dea44c455c", null ],
    [ "menu_2_select_vref", "DC1190A_8ino.html#a82af788849dcdcba5195f76838493a21", null ],
    [ "print_prompt", "DC1190A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1190A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "DC1190A_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "setup", "DC1190A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "LTC2366_bits", "DC1190A_8ino.html#a9b76812df39f1a8df448633a98f793e1", null ],
    [ "LTC2366_vref", "DC1190A_8ino.html#a3f0e40df3b3a7a28cd16e2662361e8e2", null ]
];