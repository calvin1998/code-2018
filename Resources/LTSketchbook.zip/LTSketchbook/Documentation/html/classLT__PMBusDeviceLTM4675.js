var classLT__PMBusDeviceLTM4675 =
[
    [ "clearFaultLog", "classLT__PMBusDeviceLTM4675.html#a27648246f8378d1838bb63ea3a4db5de", null ],
    [ "detect", "classLT__PMBusDeviceLTM4675.html#a39091bb01fe6a78ef73e861b5e640bfe", null ],
    [ "disableFaultLog", "classLT__PMBusDeviceLTM4675.html#ab3cc9637497d5d79febaf2313399bcac", null ],
    [ "enableFaultLog", "classLT__PMBusDeviceLTM4675.html#a948fabf0921002ec1527a355f2a16061", null ],
    [ "getCapabilities", "classLT__PMBusDeviceLTM4675.html#a03f65a63e437e330cb7d670887c86338", null ],
    [ "getFaultLog", "classLT__PMBusDeviceLTM4675.html#a06cc7be5bbafceaeeb238ccb39cbe6e3", null ],
    [ "getNumPages", "classLT__PMBusDeviceLTM4675.html#aa08f4eb75c347e901294f4bf030a7d76", null ],
    [ "hasCapability", "classLT__PMBusDeviceLTM4675.html#ae9cb95029123c84a99ee07b30363d345", null ],
    [ "hasFaultLog", "classLT__PMBusDeviceLTM4675.html#a3a7ac6d8ea9ae5d5d1a1f13bf888c754", null ],
    [ "LT_PMBusDeviceLTM4675", "classLT__PMBusDeviceLTM4675.html#a789d881209b719f191338ce4be7b8355", null ],
    [ "cap_", "classLT__PMBusDeviceLTM4675.html#a7bb8dc5d25d18d1a72b7d8f07b8aca74", null ]
];