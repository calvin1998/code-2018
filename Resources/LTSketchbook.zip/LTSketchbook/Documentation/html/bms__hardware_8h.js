var bms__hardware_8h =
[
    [ "cs_high", "bms__hardware_8h.html#aa68014b3173e5234b3c5ecc0a0456faf", null ],
    [ "cs_low", "bms__hardware_8h.html#a06afde9690afaf718d882056146ff264", null ],
    [ "delay_m", "bms__hardware_8h.html#aa84e32205db227ed29beddf995219da7", null ],
    [ "delay_u", "bms__hardware_8h.html#a0354720adfa670129da51dcd49e1417c", null ],
    [ "set_spi_freq", "bms__hardware_8h.html#a60f68c0785f48bc3bf9d069cdd876d90", null ],
    [ "spi_read_byte", "bms__hardware_8h.html#a7597887611a9d1d0ef0e5e38449dde15", null ],
    [ "spi_write_array", "bms__hardware_8h.html#a77a7c81277de45dd68652a3141312464", null ],
    [ "spi_write_read", "bms__hardware_8h.html#a6ebee974b6ad2ac4675f59d5da3d5039", null ]
];