var classLT__PMBusDeviceLTC2977 =
[
    [ "clearFaultLog", "classLT__PMBusDeviceLTC2977.html#a00f5a713a66b92661e05d73c019eba18", null ],
    [ "detect", "classLT__PMBusDeviceLTC2977.html#aae80d59711f566fabb1e5db62f04d4f5", null ],
    [ "disableFaultLog", "classLT__PMBusDeviceLTC2977.html#a8de9db488b0d70276eede67f89f75b9d", null ],
    [ "enableFaultLog", "classLT__PMBusDeviceLTC2977.html#a068890804c8602f21a7fefb3e2fbfac2", null ],
    [ "getCapabilities", "classLT__PMBusDeviceLTC2977.html#abab898aa1bd62f5d70fcf579e931629f", null ],
    [ "getFaultLog", "classLT__PMBusDeviceLTC2977.html#a30e82eb9b92517bc0db8ae21c6ce018d", null ],
    [ "getNumPages", "classLT__PMBusDeviceLTC2977.html#a23fc6501c27eab69dc23cabd8df4d0b8", null ],
    [ "getType", "classLT__PMBusDeviceLTC2977.html#ad04e5f09eca68dab0a5bd959d6f179ce", null ],
    [ "hasCapability", "classLT__PMBusDeviceLTC2977.html#a570829746b256175074d44278ad922dd", null ],
    [ "hasFaultLog", "classLT__PMBusDeviceLTC2977.html#a5c3e3ff2d427ba07259db9b657419cb6", null ],
    [ "LT_PMBusDeviceLTC2977", "classLT__PMBusDeviceLTC2977.html#afcd73722464dd5f6a03cf8cd4879a9d2", null ],
    [ "cap_", "classLT__PMBusDeviceLTC2977.html#a5cd099df75c73d5a78e5fe843614eb19", null ]
];