var DC1674A_8ino =
[
    [ "loop", "DC1674A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "read_register", "DC1674A_8ino.html#af8be800c864b8eca7b6cfb1458d2b9f1", null ],
    [ "setup", "DC1674A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "write_register", "DC1674A_8ino.html#a9c0c7111a4291ea8f2a734fdace15729", null ],
    [ "cfg", "DC1674A_8ino.html#a214d6a91586b2dc0318def15941698f7", null ],
    [ "chip", "DC1674A_8ino.html#a83497bd03d2b7088a1bb7915a4a952f8", null ],
    [ "data", "DC1674A_8ino.html#a325819a8e492ac69542e8b31705af6e9", null ],
    [ "smbus", "DC1674A_8ino.html#a345ebedd28a646dfe8397c92eddc9b78", null ]
];