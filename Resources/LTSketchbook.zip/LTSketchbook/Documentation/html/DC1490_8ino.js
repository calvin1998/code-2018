var DC1490_8ino =
[
    [ "loop", "DC1490_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_single_ended", "DC1490_8ino.html#a6c11b4744e3281567214bf2460eaa60f", null ],
    [ "menu_2_set_1X2X", "DC1490_8ino.html#af6ee27d009ac508958c849b1c472f0f6", null ],
    [ "print_prompt", "DC1490_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1490_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "setup", "DC1490_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "BUILD_1X_2X_COMMAND", "DC1490_8ino.html#a3374294ba08fc021c168de751b1d3982", null ],
    [ "demo_board_connected", "DC1490_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ],
    [ "eoc_timeout", "DC1490_8ino.html#ac9e6544152d48e7780b787e2fb92c059", null ],
    [ "LTC2460_vref", "DC1490_8ino.html#aed2ba29375ba56d544ddf0f306ea68d2", null ],
    [ "two_x_mode", "DC1490_8ino.html#a7f55451365eec7fe24c4c9024cbbbcbe", null ]
];