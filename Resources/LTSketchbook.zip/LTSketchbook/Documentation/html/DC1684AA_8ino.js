var DC1684AA_8ino =
[
    [ "discover_DC1684AB", "DC1684AA_8ino.html#ab32d16bb8474259b15da6dc6a31167b2", null ],
    [ "loop", "DC1684AA_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu1_select_dac", "DC1684AA_8ino.html#a581358d64dfde5f66f99155cd537316a", null ],
    [ "menu2_change_range", "DC1684AA_8ino.html#a3535105f1db9024c28de6d679d02d0ab", null ],
    [ "menu3_voltage_output", "DC1684AA_8ino.html#a8481a6e3dd130387268e8c9516be5e1a", null ],
    [ "menu4_square_wave_output", "DC1684AA_8ino.html#a5511c02c97f24b1f0e830589c7e7b803", null ],
    [ "print_prompt", "DC1684AA_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1684AA_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "setup", "DC1684AA_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "DAC_SELECTED", "DC1684AA_8ino.html#ac9712802ef506ecba141e16fe317de9d", null ],
    [ "DACA_RANGE_HIGH", "DC1684AA_8ino.html#abd7333be1d62fab23338d6c2fe1dbb81", null ],
    [ "DACA_RANGE_LOW", "DC1684AA_8ino.html#a7352c8fa579def93e2cb7d9651f13260", null ],
    [ "DACB_RANGE_HIGH", "DC1684AA_8ino.html#ac285523b207dad189debc63484fac70d", null ],
    [ "DACB_RANGE_LOW", "DC1684AA_8ino.html#aea55a5974f6fe34214012f5c04e76ae1", null ],
    [ "demo_board_connected", "DC1684AA_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ]
];