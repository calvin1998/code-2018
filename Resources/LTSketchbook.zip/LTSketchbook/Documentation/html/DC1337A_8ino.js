var DC1337A_8ino =
[
    [ "loop", "DC1337A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_input", "DC1337A_8ino.html#a87c15d679a0d908eab7f695628575233", null ],
    [ "menu_2_select_single_ended_differential", "DC1337A_8ino.html#aa19e7903c686b5a4e0a7c581b5f6b056", null ],
    [ "menu_3_select_uni_bipolar", "DC1337A_8ino.html#a409f2d13a4f4313c418f2a70fabe2e7b", null ],
    [ "menu_4_set_address", "DC1337A_8ino.html#ad46a6fa3e1c3afe55ef730251b1e0d41", null ],
    [ "menu_4_sleep", "DC1337A_8ino.html#a816d5afc566e03fec812cc5e127b91c7", null ],
    [ "menu_5_set_address", "DC1337A_8ino.html#a4a7564f2641a28ae64438f3331b4dda7", null ],
    [ "menu_5_sleep", "DC1337A_8ino.html#a4a1a2049bf2800c704ccf9cf6c98fbe6", null ],
    [ "print_channel_selection", "DC1337A_8ino.html#a4767da61469af7d48c859f2593bdcd7f", null ],
    [ "print_prompt", "DC1337A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1337A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command_differential", "DC1337A_8ino.html#ac9eac7080495196595b686438f2bb254", null ],
    [ "print_user_command_single_ended", "DC1337A_8ino.html#af8acb9b60fce76d543ed40826c8db9d6", null ],
    [ "setup", "DC1337A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "BUILD_COMMAND_DIFF", "DC1337A_8ino.html#acc623b3551359dcf8e66b344f86ad61e", null ],
    [ "BUILD_COMMAND_SINGLE_ENDED", "DC1337A_8ino.html#ac3dac851080025c8dfd854b08c7242f2", null ],
    [ "i2c_address", "DC1337A_8ino.html#afd5dbf719bae2b1ea9260a55e7c289cf", null ],
    [ "LTC2309_bits", "DC1337A_8ino.html#af10e96f332ea7ac7bad37b01c78b5cfc", null ],
    [ "LTC2309_vref", "DC1337A_8ino.html#a9bd8bd7becca21c7ea17f72c5d424f7e", null ],
    [ "single_ended_differential", "DC1337A_8ino.html#ae3c7526de12753393417312b2a50a04e", null ],
    [ "uni_bipolar", "DC1337A_8ino.html#a2a66cadfe70f01c77dc2ea6e51b2eaa6", null ]
];