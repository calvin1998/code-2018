var DC1096B_8ino =
[
    [ "get_code", "DC1096B_8ino.html#aae6d7a8645db319871666bb3dc4fb017", null ],
    [ "get_voltage", "DC1096B_8ino.html#a27b575d9a14b5eb84804f9627e2138ba", null ],
    [ "loop", "DC1096B_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu1_voltage_output", "DC1096B_8ino.html#adce26691192b7da272551b289db8abea", null ],
    [ "menu2_square_wave_output", "DC1096B_8ino.html#a1f10016ae4f31577d017ef2271364360", null ],
    [ "menu3_change_reference_voltage", "DC1096B_8ino.html#adaedbcfb1b06b65c3e2cfd76f530a8ef", null ],
    [ "menu4_select_range", "DC1096B_8ino.html#a471e9bdc52ad500150ce296d8dd8a9d7", null ],
    [ "print_prompt", "DC1096B_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1096B_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "prompt_voltage_or_code", "DC1096B_8ino.html#aa9565fd9bf138f09ef7788d0c4d59d48", null ],
    [ "setup", "DC1096B_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "VREF1", "DC1096B_8ino.html#a861404e425e342bc07615e246d01fd61", null ],
    [ "VREF2", "DC1096B_8ino.html#a4df04b5bcbfd9db77ac4ed54eacf80be", null ],
    [ "PROMPT_VOLTAGE", "DC1096B_8ino.html#a61dadd085c1777f559549e05962b2c9eade5fdbe90accb6c380a3b8058ce81061", null ],
    [ "PROMPT_CODE", "DC1096B_8ino.html#a61dadd085c1777f559549e05962b2c9ea9a7854699f83b2901c4aa1ae65d9a024", null ],
    [ "range", "DC1096B_8ino.html#a9edcde0584b2ab6c4a7b49eaec49d237", null ],
    [ "reference_voltage", "DC1096B_8ino.html#a55ced10a5ef8304b6466cb0566d2b2f9", null ]
];