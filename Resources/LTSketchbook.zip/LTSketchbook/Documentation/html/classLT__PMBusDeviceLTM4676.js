var classLT__PMBusDeviceLTM4676 =
[
    [ "clearFaultLog", "classLT__PMBusDeviceLTM4676.html#a80ca92ff29874732282da501a65adbaa", null ],
    [ "detect", "classLT__PMBusDeviceLTM4676.html#a0030fdd0c74c1c9db98e9b92a5deba08", null ],
    [ "disableFaultLog", "classLT__PMBusDeviceLTM4676.html#a2abc9234fc9e880e5f813cd233eac495", null ],
    [ "enableFaultLog", "classLT__PMBusDeviceLTM4676.html#af014daa89e8bd27e9f675ef417949789", null ],
    [ "getCapabilities", "classLT__PMBusDeviceLTM4676.html#aec11b14e87bc636fc8223f888bc97d03", null ],
    [ "getFaultLog", "classLT__PMBusDeviceLTM4676.html#ab1f44984030928f4a16e4b1f6aff60e2", null ],
    [ "getNumPages", "classLT__PMBusDeviceLTM4676.html#a77d1236bdfd2d643a0caaf7b771d5bc7", null ],
    [ "hasCapability", "classLT__PMBusDeviceLTM4676.html#aefcf89b0245b3bce59bb9237712c7b3d", null ],
    [ "hasFaultLog", "classLT__PMBusDeviceLTM4676.html#a1faf7e77368d7790b1f2dbf6ac8fdfdd", null ],
    [ "LT_PMBusDeviceLTM4676", "classLT__PMBusDeviceLTM4676.html#ac0a4b1cd32e60ebf49ab17ed1083bb82", null ],
    [ "cap_", "classLT__PMBusDeviceLTM4676.html#a27aab9147585d4e304fe741c15986618", null ]
];