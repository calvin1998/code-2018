var classLT__PMBusDeviceLTC3880 =
[
    [ "clearFaultLog", "classLT__PMBusDeviceLTC3880.html#a6176be2c9c153a1a33f8c969875af8ff", null ],
    [ "detect", "classLT__PMBusDeviceLTC3880.html#ae198457d53e937e725183b92b536f409", null ],
    [ "disableFaultLog", "classLT__PMBusDeviceLTC3880.html#a28ba19ae34782bd2a0744ab6c6991f20", null ],
    [ "enableFaultLog", "classLT__PMBusDeviceLTC3880.html#a50292ca34d0542b3c7daf8112d82a3a3", null ],
    [ "getCapabilities", "classLT__PMBusDeviceLTC3880.html#a81b434b9231b86fc4a72af233c784911", null ],
    [ "getFaultLog", "classLT__PMBusDeviceLTC3880.html#a3280d3dd9957829c48277ebfcd60d7a4", null ],
    [ "getNumPages", "classLT__PMBusDeviceLTC3880.html#abf402c9665de09381ee0fe56af73a9b9", null ],
    [ "hasCapability", "classLT__PMBusDeviceLTC3880.html#a12515507bc2c7eb9c8607f6e4bcba77f", null ],
    [ "hasFaultLog", "classLT__PMBusDeviceLTC3880.html#aac25f0807d2c9aaedc4aaf4d0fca493e", null ],
    [ "LT_PMBusDeviceLTC3880", "classLT__PMBusDeviceLTC3880.html#ab2af5cd7356a51ce952d536176db9bda", null ],
    [ "cap_", "classLT__PMBusDeviceLTC3880.html#aabb1b27be1de5cee98fe6b50170d4434", null ]
];