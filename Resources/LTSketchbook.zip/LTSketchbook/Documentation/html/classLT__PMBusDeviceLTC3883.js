var classLT__PMBusDeviceLTC3883 =
[
    [ "clearFaultLog", "classLT__PMBusDeviceLTC3883.html#a5d074f1c5b32f671debff5af999c16fc", null ],
    [ "detect", "classLT__PMBusDeviceLTC3883.html#ad346f57ed5726a9bd31a124f4d62307b", null ],
    [ "disableFaultLog", "classLT__PMBusDeviceLTC3883.html#acd80fc6cadd1145dbc3377a5c2fb671b", null ],
    [ "enableFaultLog", "classLT__PMBusDeviceLTC3883.html#a8e5733c357f269823d31c85c3e236475", null ],
    [ "getCapabilities", "classLT__PMBusDeviceLTC3883.html#a0de70fc6933371cc1867709718abbb06", null ],
    [ "getFaultLog", "classLT__PMBusDeviceLTC3883.html#a25b57aa9c08b941b3642ccbeb2103b1b", null ],
    [ "getNumPages", "classLT__PMBusDeviceLTC3883.html#aa41c305860bda40883b39d46a495a3fd", null ],
    [ "hasCapability", "classLT__PMBusDeviceLTC3883.html#a7a029d743a39e0f34de938b6a14ee65b", null ],
    [ "hasFaultLog", "classLT__PMBusDeviceLTC3883.html#a93f6b420c2af407a5cf4a0a4e89d0323", null ],
    [ "LT_PMBusDeviceLTC3883", "classLT__PMBusDeviceLTC3883.html#a38769fd21e1c53126ff8b5f1a94f7ebb", null ],
    [ "cap_", "classLT__PMBusDeviceLTC3883.html#a3aa7240b66514601c5aad5b70c002bf5", null ]
];